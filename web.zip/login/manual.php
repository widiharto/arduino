<html>
<head>
	<title></title>
</head>
<body>
<div class="container" align="Center">
	<h2>Kendali Manual</h2><br>
	<a class="btn btn-info" role="button" href="a.php" title="Nyalakan Pompa"><i class="fa fa-shower"></i> Nyalakan Pompa</a>
	<a class="btn btn-warning" role="button" href="b.php" title="Nyalakan Lampu"><i class="fa fa-lightbulb-o"></i> Nyalakan Lampu</a><br><br>
	<a href="c.php" class="btn btn-lg btn-danger" title="Berhenti Darurat"><span class="glyphicon glyphicon-off"></span> Berhenti Darurat</a><br><br>
	<p>* Berhenti Darurat untuk mematikan sistem</p>
	<p>* Untuk mengaktifkan sistem restart Arduino IDE atau tekan RESET pada Arduino</p>
</div>
</body>
</html>