<?php
$fp =fopen("COM3","w");
?>
<script language script="JavaScript">
	alert('Pompa Air Aktif');
	document.location='index.php?halaman=manual';
</script>
<meta http-equiv="refresh" content="0;URL='index.php?halaman=manual'" />   

<html>
<head>
	<title></title>
</head>
<body>
<a href="index.php?halaman=manual">KEMBALI</a>
</body>
</html>
<?php
fwrite($fp, "A");
fclose($fp);
?>
 