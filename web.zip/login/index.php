<?php
//include "ethernet.php";
include "hari.php";
?>
<html>
<head>
<?php  
  
$url = $_SERVER['REQUEST_URI'];  
  
//header("Refresh: 10; URL=$url");  
  
?> 
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/bootstrap-theme.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <script src="js/jquery.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css" />
    <script src="js/bootstrap-datetimepicker.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<title>AUTOMATIC SPRINKLERS</title>
<style>
.navbar-inverse {
    border-radius: 0;
}
.pompa {
   color: blue;
   }
.lampu {
   color: red;
   }
.normal {
   color: yellow;
   }
</style>
</style>
<link rel="icon" type="image/png" sizes="16x16" href="fav/favicon-16x16.png">
</head>
<body>
<nav class="navbar navbar-inverse">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/login" title="AUTOMATIC SPRINKLERS"><i class="fa fa-laptop"></i> Automatic Sprinklers</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
              <?php
                session_start();
                error_reporting(E_ALL^E_NOTICE);
                $halaman = $_GET['halaman'];

                if($_SESSION['username']=="admin"){
                  echo "
                      <li><a href='index.php' title='Beranda'><span class='glyphicon glyphicon-home'></span> Beranda</a></li>
                      <li><a href='?halaman=view' title='Lihat Tabel'><span class='fa fa-table'></span> Lihat Tabel</a></li>
                      <li><a href='?halaman=grafik' title='Grafik'><span class='fa fa-bar-chart'></span> Lihat Grafik</a></li>
                      <li><a href='?halaman=manual' title='Kendali Manual'><span class='glyphicon glyphicon-hand-up'></span> Kendali Manual</a></li>
                      <li><a href='?halaman=stop' title='Berhenti Darurat'><span class='glyphicon glyphicon-off'></span> Berhenti Darurat</a></li>
                      <li><a href='logout.php' title='Keluar'><span class='glyphicon glyphicon-log-out'></span> Keluar</a></li>
                  ";
                  
                }else{
                  echo "
                      <li><a href='login.php' title='Masuk'><span class='glyphicon glyphicon-log-in'></span> Masuk</a></li>
                  ";
                }
                ?>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<div class="container">

<?php
//echo "<h4>Suhu saat ini ".$suhu."°C</h4>";
echo "<h4>Suhu ".$suhuku."°C</h4>";
echo "<h4>Kelembaban ".$kelembaban."%</h4>";
//echo "$suhu";

if($suhuku<18 && $kelembaban>80){
  echo "<h3 class='lampu'>Lampu Penghangat Menyala</h3>";
}
else if($suhuku>18 && $kelembaban<60){
  echo "<h3 class='pompa'>Pompa Air Menyala</h3>";
}
else if($suhuku<18 && $kelembaban<60){
  echo "<font size='5' class='pompa'>Pompa Air</font> <font size='5'>dan</font><font size='5' class='lampu'> Lampu Penghangat Menyala</font>";
}
else if (($suhuku >= 18 && $suhuku <=30)  && ($kelembaban >= 60 )){

  echo "<h3 class='normal'>Normal</h3>";
}
?>

<hr/>

<?php
switch($halaman){
	case "manual" : include "manual.php" ; break;
	case "view"	: include "view.php"; break;
  case "stop" : include "c.php"; break;
  case "grafik" : include "grafik.php"; break;
  default : include "home.php";break;
}
?>
</div>
<!-- input data -->

<div class="container">
<?php
$isi="INSERT INTO data1 (no,hari,tanggal,suhu,durasisemprot,durasilampu,durasinormal) VALUES (NULL,'$hari','$tanggal||$waktu',$suhu,10,0,0)";
//mysqli_query($conn, $isi); //untuk input data ke database

//////////////////////////////////////////////////////////////////////////

$masuk='';
if($suhu>=30){
$masuk= "INSERT INTO data1 (no,hari,tanggal,suhu,durasisemprot,durasilampu,durasinormal) VALUES (NULL,'$hari','$datetime',$suhu,10,0,0)";
}
else if($suhu<=25){
$masuk= "INSERT INTO data1 (no,hari,tanggal,suhu,durasisemprot,durasilampu,durasinormal) VALUES (NULL,'$hari','$datetime',$suhu,0,10,0)";
}
else{
$masuk= "INSERT INTO data1 (no,hari,tanggal,suhu,durasisemprot,durasilampu,durasinormal) VALUES (NULL,'$hari','$datetime',$suhu,0,0,10)";
}
//mysqli_query($conn, $masuk);  // untuk input data ke databse
//////////////////////////////////////////////////////////////////////////

$masuk2='';
if($suhuku<18 && $kelembaban>80){
$masuk2= "INSERT INTO data2 (no,hari,tanggal,suhu,kelembaban,durasisemprot,durasilampu,durasisemprotlampu,durasinormal) VALUES (NULL,'$hari','$datetime',$suhuku,$kelembaban,0,10,0,0)";
}
else if($suhuku>18 && $kelembaban<60){
$masuk2= "INSERT INTO data2 (no,hari,tanggal,suhu,kelembaban,durasisemprot,durasilampu,durasisemprotlampu,durasinormal) VALUES (NULL,'$hari','$datetime',$suhuku,$kelembaban,10,0,0,0)";
}
else if($suhuku<18 && $kelembaban<60){
$masuk2= "INSERT INTO data2 (no,hari,tanggal,suhu,kelembaban,durasisemprot,durasilampu,durasisemprotlampu,durasinormal) VALUES (NULL,'$hari','$datetime',$suhuku,$kelembaban,0,0,10,0)";
}
else if (($suhuku >= 18 && $suhuku <=30)  && ($kelembaban >= 60 )){ //&& $kelembaban <= 80
$masuk2= "INSERT INTO data2 (no,hari,tanggal,suhu,kelembaban,durasisemprot,durasilampu,durasisemprotlampu,durasinormal) VALUES (NULL,'$hari','$datetime',$suhuku,$kelembaban,0,0,0,10)";
}
//mysqli_query($conn, $masuk2);  // untuk input data ke databse
?>
</div>
<!-- akhir input data -->
<br><br>
    <div class="container">
    <hr/>
      <p>&copy; 2016 <a href="/login" title="Beranda">AUTOMATIC SPRINKLERS</a></p>
    </div>
</body>
</html>