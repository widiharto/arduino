<?php 
include('koneksi.php');
include "hari.php";

//////////////////////////////////// penjumlahan durasi
if (isset($_GET['awal']) AND isset($_GET['akhir'])) {
	$awal = $_GET['awal'];
	$akhir = $_GET['akhir'];
	$Normal =  $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' AND durasinormal =10");
	$Pompa =  $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' AND durasisemprot =10");
	$PompaLampu =  $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' AND durasisemprotlampu =10");
	$Lampu =  $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' AND durasilampu =10");
}
else{
	$Normal =  $conn->query("SELECT * FROM data2 WHERE durasinormal =10");
	$Pompa =  $conn->query("SELECT * FROM data2 WHERE durasisemprot =10");
	$PompaLampu =  $conn->query("SELECT * FROM data2 WHERE durasisemprotlampu =10");
	$Lampu =  $conn->query("SELECT * FROM data2 WHERE durasilampu =10");
}

$durnor = 0 ;
$durpom = 0 ;
$durlam = 0 ;
$durpomlam = 0 ;

while($a = $Normal->fetch_assoc()) :
	$durnor = $durnor + 1;
 endwhile;
while($a = $Pompa->fetch_assoc()) :
	$durpom = $durpom + 1;
 endwhile;
while($a = $PompaLampu->fetch_assoc()) :
	$durpomlam = $durpomlam + 1;
 endwhile;
while($a = $Lampu->fetch_assoc()) :
	$durlam = $durlam + 1;
 endwhile;
 /////////////////////////////// penjumlahan durasi sampai sini

//$hasil = $conn->query("SELECT * FROM data1 ORDER BY no DESC");

if (isset($_GET['awal']) AND isset($_GET['akhir'])) {
	$awal = $_GET['awal'];
	$akhir = $_GET['akhir'];
	$hasil = $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' ORDER BY no DESC");
}
else{
	$hasil = $conn->query("SELECT * FROM data2 ORDER BY no DESC");
}

ob_start();
require_once 'dompdf/autoload.inc.php';
// reference the Dompdf namespace

echo "<h2 align='center'>TABEL PENYIRAMAN</h2></br>";
echo "<center>";
echo "Hari ".$hari.", ";
echo $tanggal;
echo "<br>";
echo "Pukul : ".$waktu;
echo "</center>";
echo "<br>";
echo "<table  width='100%' border='1px' align='center'>";
echo "<tr align='center' >";
echo "<td><b>No</b></td>";
echo "<td><b>Hari</b></td>";
echo "<td><b>Tanggal / Waktu</b></td>";
echo "<td><b>Suhu (°C)</b></td>";
echo "<td><b>Kelembaban (%)</b></td>";
echo "<td><b>Periode Refresh Data Pompa (s)</b></td>";
echo "<td><b>Periode Refresh Data Lampu (s)</b></td>";
echo "<td><b>Periode Refresh Data Pompa & Lampu (s)</b></td>";
echo "<td><b>Periode Refresh Data Normal (s)</b></td>";
echo "</tr>";

$no = 0 ;

while($i = $hasil->fetch_assoc()) :
	$no = $no + 1;

echo "<tr align='center'>";
echo "<td>".$no."</td>";
echo "<td>".$i['hari']."</td>";
echo "<td>".$i['tanggal']."</td>";
echo "<td>".$i['suhu']."</td>";
echo "<td>".$i['kelembaban']."</td>";
echo "<td>".$i['durasisemprot']."</td>";
echo "<td>".$i['durasilampu']."</td>";
echo "<td>".$i['durasisemprotlampu']."</td>";
echo "<td>".$i['durasinormal']."</td>";
echo "</tr>";

endwhile;

echo "</table";
echo "* Data di perbaruhi setiap 10 detik";
echo "<br><br><b>";
echo 'Durasi pompa adalah : '.($durpom*10).' detik'.'<br>';
echo 'Durasi lampu adalah : '.($durlam*10).' detik'.'<br>';
echo 'Durasi pompa & lampu adalah : '.($durpomlam*10).' detik'.'<br>';
echo 'Durasi normal adalah : '.($durnor*10).' detik'.'<br>';
echo "</b>";

use Dompdf\Dompdf;
// instantiate and use the dompdf class
$dompdf = new Dompdf();
	$dompdf->loadHtml(ob_get_contents());
	ob_end_clean();
	// (Optional) Setup the paper size and orientation
	$dompdf->setPaper('A4', 'portrait');

	// Render the HTML as PDF
	$dompdf->render();

	// Output the generated PDF to Browser
	$dompdf->stream('Laporan - '.date("d-m-Y"));
	//ob_get_contents();

?>