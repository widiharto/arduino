<script type="text/javascript" src="fusionchart/js/fusioncharts.js"></script>
<script type="text/javascript" src="fusionchart/js/themes/fusioncharts.theme.fint.js"></script>
<?php
include('koneksi.php');
include "hari.php";
include "durasi.php";
include "pagination.php";
include 'fusionchart/fusioncharts.php';

if (isset($_GET['awal']) AND isset($_GET['akhir'])) {
	$awal = $_GET['awal'];
	$akhir = $_GET['akhir'];
	$hasil = $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' ORDER BY no DESC");
	$rows = $hasil->num_rows;
	$pager = new Pagination("/login/index.php?halaman=grafik&awal={$awal}&akhir={$akhir}", $rows);
	$pager = $pager->get();
	$hasil = $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' ORDER BY no DESC LIMIT {$pager['perpage']} OFFSET {$pager['offset']}");
}
else {
	$hasil = $conn->query("SELECT * FROM data2 ORDER BY no DESC");
	$rows = $hasil->num_rows;
	$pager = new Pagination("/login/index.php?halaman=grafik", $rows);
	$pager = $pager->get();
	$hasil = $conn->query("SELECT * FROM data2 ORDER BY no DESC LIMIT {$pager['perpage']} OFFSET {$pager['offset']}");
}

//Nyeluk data di  mana durasi semprot = 10 detik
// $hasil = $conn->query("SELECT * FROM data1 WHERE durasisemprot =10");
//Nyeluk data di  mana waktu 1 jam terakir
?>
<?php


//echo $conn->error;
//die(var_dump($hasil));


?>
<h2 align="center">GRAFIK PENYIRAMAN</h2>
<center>
Hari
<?php
echo $hari;
?>,
<?php
echo $tanggal;
?>
<div align="center">
<?php
echo "Pukul : ";
echo $waktu;
?>
<br />
<!-- refresh page 5 menit input data hari tanggal waktu -->
</div>
<br><br>
<!-- /////////////// -->
<div align="center">
<form method="get" align="left">
<input type="hidden" name="halaman" value="grafik" />
<div class="col-md-6">
	<div class='col-md-2' style="padding-top: 6px;font-weight: bold;">
		Mulai
	</div>
    <div class='col-md-3'>
        <div class="form-group">
            <div class='input-group date'>
                <input type='text' name="awal" class="form-date form-control" style="border-radius: 5px;" required />
            </div>
        </div>
    </div>
    <div class='col-md-2' style="padding-top: 6px;font-weight: bold;">
    sampai
    </div>
    <div class='col-md-3'>
        <div class="form-group">
            <div class='input-group date'>
                <input type='text' name="akhir" class="form-date form-control" style="border-radius: 5px;" required />
            </div>
        </div>
    </div>
    <div class='col-md-2'>
		<button class="btn btn-info">Filter</button>
	</div>
</div>
<div align="center" id="chartContainer1">FusionCharts XT will load here!</div>
</form>
</div>
<script type="text/javascript">
    $(function () {
        $(".form-date").datetimepicker({
	        format: "yyyy-mm-dd",
	        weekStart: 1,
	        todayBtn:  1,
			autoclose: 1,
			todayHighlight: 1,
			startView: 2,
			minView: 2,
			forceParse: 0,
	    });
    });
</script>
<!-- //////////////// -->
<script type="text/javascript">
	FusionCharts.ready(function(){
	      var revenueChart = new FusionCharts({
	        "type": "column3d",
	        "renderAt": "chartContainer1",
	        "width": "800",
	        "height": "500",
	        "dataFormat": "json",
	        "dataSource": {
	          "chart": {
	              "caption": " ",
	              "subCaption": " ",
	              "xAxisName": "Alat",
	              "yAxisName": "Durasi (detik)",
	              "theme": "fint"
	           },
	          "data": [
	              {
	                 "label": "Pompa",
	                 "value": "<?php echo $durpom*10; ?>"
	              },
	              {
	                 "label": "Lampu",
	                 "value": "<?php echo $durlam*10; ?>"
	              },
	              {
	                 "label": "Pompa & Lampu",
	                 "value": "<?php echo $durpomlam*10; ?>"
	              },
	              {
	                 "label": "Normal",
	                 "value": "<?php echo $durnor*10; ?>"
	              }
	           ]
	        }
	    });

	    revenueChart.render();
	})
</script>

<br>
<b>
<?php
 echo 'Durasi pompa adalah '.($durpom*10).' detik'.'</br>';
 echo 'Durasi lampu adalah '.($durlam*10).' detik'.'</br>';
 echo 'Durasi pompa & lampu adalah '.($durpomlam*10).' detik'.'</br>';
 echo 'Durasi normal adalah '.($durnor*10).' detik'.'</br>';
?>
</b>
<body>