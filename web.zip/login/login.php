<?php
session_start();
include "koneksi.php";
include "ethernet.php";

@$username = $_POST['username'];
@$password = md5($_POST['password']);
@$submit = $_POST['submit'];

if($submit){
	$sql = "select * from user where username='$username' and password='$password' ";
	//$query = mysql_query($sql);
    $query =  $conn->query($sql);
	//$row = mysql_fetch_array($query);
    $row = $query->fetch_array();
	if($row['username']!=""){
		//berhasil login
		$_SESSION['username']=$row['username'];
		//$_SESSION['status']=$row['status'];
	?>
			<script language script="JavaScript">
			alert('Anda Masuk <?php echo $row['username']; ?>');
			document.location='index.php';
			</script>
	<?php

	}else{
		//gagal login
			?>
			<script language script="JavaScript">
			alert('Gagal Login');
			document.location='login.php';
			</script>	
		<?php

	}
}


?>
<html>
<head>
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
		<title>AUTOMATIC SPRINKLERS</title>
<style>
.navbar-inverse {
    border-radius: 0;
}
</style>
</head>
<body>
<nav class="navbar navbar-inverse">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="/login" title="AUTOMATIC SPRINKLERS">AUTOMATIC SPRINKLERS</a>
        </div>
      </div>
</nav>
<div class="container">
<?php
echo "<h4>Suhu ".$suhuku."°C</h4>";
echo "<h4>Kelembaban ".$kelembaban."%</h4>";
?>
<hr/>
</div>
    <div class="container" style="max-width: 280px;">
        <div class="row" align="center">
            <h2>Masuk</h2>
            <div class="login">
                <form role="form" action="login.php" method="post">
                    <div class="form-group">
                        <input type="text" name="username" class="form-control" placeholder="Username" title="Username" required autofocus />
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="Password" title="Password" required autofocus />
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" class="btn btn-primary btn-block" value="Masuk" title="Masuk" />
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="container">
    <hr/>
        <p>&copy; 2016 <a href="/login" title="AUTOMATIC SPRINKLERS">AUTOMATIC SPRINKLERS</a></p>
    </div>
</body>
</html>