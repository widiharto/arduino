
<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
include "koneksi.php";


$input="insert into user (username, password, nama, status) values 
('$txtusername', '$txtpassword', '$txtnama', '$txtstatus')";
mysql_query($input);
?>