<form method="get" action="">
<input type="hidden" name="halaman" value="view" />
<div class="col-md-6" style="padding-left: 0px;
    border: 1px solid #ddd;
    padding-top: 6px;
    height: 50px;
    border-radius: 5px;
    margin-bottom: 10px;">
	<div class='col-md-2' style="padding-top: 6px;font-weight: bold;">
		Mulai
	</div>
    <div class='col-md-3'>
        <div class="form-group">
            <div class='input-group date'>
                <input type='text' name="awal" class="form-date form-control" style="border-radius: 5px;" required />
            </div>
        </div>
    </div>
    <div class='col-md-2' style="padding-top: 6px;font-weight: bold;">
    sampai
    </div>
    <div class='col-md-3'>
        <div class="form-group">
            <div class='input-group date'>
                <input type='text' name="akhir" class="form-date form-control" style="border-radius: 5px;" required />
            </div>
        </div>
    </div>
    <div class='col-md-2'>
		<button class="btn btn-info">Filter</button>
	</div>
</div>
</form>