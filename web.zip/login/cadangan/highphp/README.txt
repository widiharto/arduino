README

untuk mencobanya di localhost, pastikan anda sdah menginstall apache,php, mysql
saya sendiri menggunakan XAMPP 1.7.4 

berikut ini cara menginstall script 
1. buat database dengan nama candralabdb;
2. Import file penjualan.sql ke database tersebut
3. jika server mysql ada passwordnya maka tambahkan password di file config.php
4. letakan file hasil extract di folder htdocs misalkan foldernya highphp
5. pastikan server apache dan mysql jalan
6. lalu buka http://localhost/highphp/grafik.php

selamat mencoba, bermasalah? silahkan follow @candraadiputra di twitter