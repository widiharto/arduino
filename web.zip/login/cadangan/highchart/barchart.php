<html>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>

<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

<table id="datatable">
    <thead>
        <tr>
            <th></th>
            <th>Jane</th>
            <th>John</th>
            <th>Titit</th>
            <th>Yono</th>
            <th>Uhuk</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th>Apples</th>
            <td>3</td>
            <td>4</td>
            <td>10</td>
            <td>5</td>
            <td>6</td>
        </tr>
        <tr>
            <th>Pears</th>
            <td>2</td>
            <td>1</td>
            <td>4</td>
            <td>10</td>
            <td>5</td>
        </tr>
        <tr>
            <th>Plums</th>
            <td>5</td>
            <td>11</td>
            <td>4</td>
            <td>10</td>
            <td>5</td>
        </tr>
        <tr>
            <th>Bananas</th>
            <td>1</td>
            <td>1</td>
            <td>4</td>
            <td>10</td>
            <td>5</td>
        </tr>
        <tr>
            <th>Oranges</th>
            <td>2</td>
            <td>4</td>
            <td>4</td>
            <td>10</td>
            <td>5</td>
        </tr>
    </tbody>
</table>
</html>