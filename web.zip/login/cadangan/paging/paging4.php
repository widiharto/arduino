<?php
include('koneksi.php');
include "hari.php";
include "durasi.php";
$hasil = $conn->query("SELECT * FROM data1 ORDER BY no DESC");
//Nyeluk data di  mana durasi semprot = 10 detik
// $hasil = $conn->query("SELECT * FROM data1 WHERE durasisemprot =10");
//Nyeluk data di  mana waktu 1 jam terakir
?>

<!-- //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//RULE DATA ALL DI SIMPEN 
// DATA SEMPROT DI SIMPEN JUGA
 -->

<H4>PROGRESS BAR</H4>
<div class="progress">
  <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" style="<?php echo $wdurpom;?>%" title="POMPA AIR AKTIF"> <!-- progress-bar-info -->
    POMPA MENYALA
  </div>
  <div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" style="<?php echo $wdurlam;?>%" title="LAMPU AKTIF">
    PEMANAS MENYALA
  </div>
  <div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" style="<?php echo $wdurnor;?>%" title="KEADAAN NORMAL">
    NORMAL
  </div>
</div>
<?php


//echo $conn->error;
//die(var_dump($hasil));


?>
<hr/>
<h2 align="center">TABEL PENYIRAMAN</h2>
<center>
Hari
<?php
echo $hari;
?>,
<?php
echo $tanggal;
?>
<div align="center">
<?php
echo "Pukul : ";
echo $waktu;
?>
<?php

?>

<br />
<!-- refresh page 5 menit input data hari tanggal waktu -->
</div>
<br>
<table <?php if (  isset($_GET['print'])) : ?> width="100%" border="1px solid" <?php endif; ?> class="table table-striped table-responsive">

<tr align="center" >
<td><b>No</b></td>
<td><b>Hari</b></td>
<td><b>Tanggal / Waktu</b></td>
<td><b>Suhu (°C)</b></td>
<td><b>Durasi Pompa (s)</b></td>
<td><b>Durasi Lampu (s)</b></td>
<td><b>Durasi Normal (s)</b></td>
</tr>
<?php 
$no = 0 ;

while($i = $hasil->fetch_assoc()) :
	$no = $no + 1;
 ?>

	<tr align="center">
	<td><?php echo $no ?></td>
	<td><?php echo $i['hari']; ?></td>
	<td><?php echo $i['tanggal']; ?></td>
	<td><?php echo $i['suhu']; ?></td>
	<td><?php echo $i['durasisemprot']; ?></td>
	<td><?php echo $i['durasilampu']; ?></td>
	<td><?php echo $i['durasinormal']; ?></td>
	</tr>
	
<?php endwhile; ?>
</table>
</center>
<p>* Data di perbaruhi setiap 10 detik</p>
<?php
 echo 'Durasi pompa adalah  : '.($durpom*10).' detik'.'</br>';
 echo 'Durasi lampu adalah   : '.($durlam*10).' detik'.'</br>';
 echo 'Durasi normal adalah : '.($durnor*10).' detik'.'</br>';
?>


<body>
<center></br>
	<a href="cetak.php" class="btn btn-success btn-lg" title="Print Table"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Save to PDF</a><br><br>
	<a href="c.php" class="btn btn-lg btn-danger" title="EMERGENCY STOP"><span class="glyphicon glyphicon-off"></span> EMERGENCY STOP</a>
</center>