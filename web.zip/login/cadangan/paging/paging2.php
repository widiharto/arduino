<html>
<title>Data Paging</title>
<link href="style.css" rel="stylesheet" type="text/css">
<body>

<?php
include "koneksi.php";
//$konek = mysqli_connect("localhost","root","","kelasa_db");

// Langkah 1. Tentukan batas,cek halaman & posisi data
$batas   = 10;
$halaman = @$_GET['halaman'];
if(empty($halaman)){
	$posisi  = 0;
	$halaman = 1;
}
else{ 
  $posisi  = ($halaman-1) * $batas; 
}

// Langkah 2. Sesuaikan query dengan posisi dan batas
$query  = "SELECT * FROM data1 ORDER BY no DESC LIMIT $posisi,$batas";
$tampil = mysqli_query($conn, $query);

echo "<table>
<tr>
    <td>No</td>
    <td>Hari</td>
    <td>Tanggal / Waktu</td>
    <td>Suhu (°C)</td>
    <td>Durasi Pompa (s)</td>
    <td>Durasi Normal (s)</td>
    <td>Durasi Lampu (s)</td>
</tr>";

$no = $posisi+1;
while ($data=mysqli_fetch_array($tampil)){
  echo "<tr>
    <td>$no</td>
    <td>$data[hari]</td>
    <td>$data[tanggal]</td>
    <td>$data[suhu]</td>
    <td>$data[durasisemprot]</td>
    <td>$data[durasinormal]</td>
    <td>$data[durasilampu]</td>
</tr>";
  $no++;
} 
echo "</table>"; 

// Langkah 3: Hitung total data dan halaman serta link 1,2,3 
$query2     = mysqli_query($conn, "select * from data1");
$jmldata    = mysqli_num_rows($query2);
$jmlhalaman = ceil($jmldata/$batas);

echo "<br> Halaman : ";

for($i=1;$i<=$jmlhalaman;$i++)
if ($i != $halaman){
	echo " <a href=\"paging2.php?halaman=$i\">$i</a> | ";   //paging2.php?halaman=$i
}
else{ 
	echo " <b>$i</b> | "; 
}
echo "<p>Total anggota : <b>$jmldata</b> orang</p>";
?>
