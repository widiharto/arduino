<?php
include "koneksi.php";


$batas   = 10;
$halaman = @$_GET['halaman'];
if(empty($halaman)){
	$posisi  = 0;
	$halaman = 1;
}
else{ 
  $posisi  = ($halaman-1) * $batas; 
}

// Langkah 2. Sesuaikan query dengan posisi dan batas
$query  = "SELECT * FROM data1 ORDER BY no DESC LIMIT $posisi,$batas";
$tampil = mysqli_query($conn, $query);

echo "<table width='100%' border='0px solid' class='table table-striped table-responsive'>
<tr>
    <td>No</td>
    <td>Hari</td>
    <td>Tanggal / Waktu</td>
    <td>Suhu (°C)</td>
    <td>Durasi Pompa (s)</td>
    <td>Durasi Normal (s)</td>
    <td>Durasi Lampu (s)</td>
</tr>";

$no = $posisi+1;
while ($data=mysqli_fetch_array($tampil)){
  echo "<tr>
    <td>$no</td>
    <td>$data[hari]</td>
    <td>$data[tanggal]</td>
    <td>$data[suhu]</td>
    <td>$data[durasisemprot]</td>
    <td>$data[durasinormal]</td>
    <td>$data[durasilampu]</td>
</tr>";
  $no++;
}
echo "</table>";
$query2     = mysqli_query($conn, "select * from data1");
$jmldata    = mysqli_num_rows($query2);
$jmlhalaman = ceil($jmldata/$batas);

echo "<br> Halaman : ";

for($i=1;$i<=$jmlhalaman;$i++)
if ($i != $halaman){
	echo " <a href=\"paging3.php?halaman=$i\">$i</a> | ";
}
else{ 
	echo " <b>$i</b> | "; 
}
echo "<p>Total anggota : <b>$jmldata</b> orang</p>";

?>