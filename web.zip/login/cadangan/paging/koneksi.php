<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'kelasa_db';
$conn = new mysqli($host, $user, $pass, $db);
?>