<!DOCTYPE html><html>
<head>
<title>PHP Pagination</title>
</head><body><?php
// Establish Connection to the Database
$con = mysqli_connect('localhost','root','','kelasa_db');//Records per page
$per_page=15;
if (isset($_GET["page"])) {

$page = $_GET["page"];

}

else {

$page=1;

}

// Page will start from 0 and Multiple by Per Page
$start_from = ($page-1) * $per_page;

//Selecting the data from table but with limit
$query = "SELECT * FROM data1 ORDER BY no DESC LIMIT $start_from, $per_page";
$result = mysqli_query ($con, $query);

?>
<table align="center" border="2" cellpadding="3">
<tr>
    <td>No</td>
    <td>Hari</td>
    <td>Tanggal / Waktu</td>
    <td>Suhu (°C)</td>
    <td>Durasi Pompa (s)</td>
    <td>Durasi Normal (s)</td>
    <td>Durasi Lampu (s)</td>
</tr>
<?php 
$no = 0 ;

while($row = $result->fetch_assoc()) :
	$no = $no + 1;
 ?>
<?php
//while ($row = mysqli_fetch_assoc($result)) {
?>
<tr align="center">
	<td><?php echo $no; ?></td>
	<td><?php echo $row['hari']; ?></td>
	<td><?php echo $row['tanggal']; ?></td>
	<td><?php echo $row['suhu']; ?></td>
	<td><?php echo $row['durasisemprot']; ?></td>
	<td><?php echo $row['durasilampu']; ?></td>
	<td><?php echo $row['durasinormal']; ?></td>
</tr>
<?php endwhile;//};
?>
</table>

<div>
<?php

//Now select all from table
$query = "SELECT * FROM data1";
$result = mysqli_query($con, $query);

// Count the total records
$total_records = mysqli_num_rows($result);

//Using ceil function to divide the total records on per page
$total_pages = ceil($total_records / $per_page);

//Going to first page
echo "<center><a href='paging5.php?page=1'>".'First Page'."</a> ";

for ($i=1; $i<=$total_pages; $i++) {

echo "<a href='paging5.php?page=".$i."'>".$i."</a> ";
};
// Going to last page
echo "<a href='paging5.php?page=$total_pages'>".'Last Page'."</a></center> ";
?>

</div>

</body>
</html>