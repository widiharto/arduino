<html>
<title>Data Tanpa Paging</title>
<link href="style.css" rel="stylesheet" type="text/css">
<body>

<?php
$konek = mysqli_connect("localhost","root","","cerdas");

$query  = "SELECT * FROM anggota";
$tampil = mysqli_query($konek, $query);

echo "<table>
      <tr><th>No</th><th>Nama</th><th>Alamat</th></tr>";

$no = 1;
while ($data=mysqli_fetch_array($tampil)){
  echo "<tr>
          <td>$no</td>
          <td>$data[nama]</td>
          <td>$data[alamat]</td>
        </tr>";
  $no++;
} 
echo "</table>";
?>
