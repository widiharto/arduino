<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Membuat Statistik Pendaftar dengan Php,Boostrap dan Mysqli</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
	    <link href="assets/css/bootstrap.css" rel="stylesheet" media="screen">
        <link href="assets/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
		 <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
		<link href="assets/css/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
    <style>
      body {
        padding-top: 60px; /* 60px to make the container go all the way to the bottom of the topbar */
      }
    </style>
    <link href="assets/css/bootstrap-responsive.css" rel="stylesheet">

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="../assets/js/html5shiv.js"></script>
    <![endif]-->

    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
      <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
                    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
                                   <link rel="shortcut icon" href="assets/ico/favicon.png">
  </head>

  <body>

    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
          <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="brand" href="http://andeznet.com">AndezNet</a>
          <div class="nav-collapse collapse">
            <ul class="nav">
              <li class="active"><a href="#">Home</a></li>
              <li><a href="#">Grafik</a></li>
              <li><a href="#">Logout</a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div>
      </div>
    </div>
	
<div class="container">
<h2>STATISTIK PENDAFTAR</h2>
<h3>Penerimaan Siswa Baru <a href="https:facebook.com/dp1n2jkt">SMK Dinamika Pembangunan 1 Jakarta</a></h3>
<p>Berdasarkan Jurusan</p>

<div class="block-content collapse in">
							
<?php

$hasil = mysqli_query($db,"SELECT * FROM t_jurusan where id_jur >1");
while ($data = mysqli_fetch_row($hasil))
{
$kodejur= $data[0];
$jurusan= $data[1];
$quota=$data[4];

$hasil2 = mysqli_query($db,"SELECT count(*) as jum FROM master WHERE jrsn_pil1 = '$kodejur'");
$data2 = mysqli_fetch_row($hasil2);
$jumlah = $data2[0]; 
$datapercent= $jumlah / $quota * 100;


echo"			
<div class='span1'>
<div class='chart' data-percent='".substr($datapercent,0,4)."'>".substr($datapercent,0,4)."% <span class='label label-info'>".$jurusan."</span></div>
</div>";

};


?>
</div>


<div class="table-responsive">	  
<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" >
<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
echo "<tr><th>NO</th><th>JURUSAN</th><th>KELAS</th><th>L</th><th>P</th><th>JUMLAH SISWA</th><th>QUOTA</th><th>KURANG</th>";  

$no = 1;

$totalSiswa = 0;

$hasil = mysqli_query($db,"SELECT * FROM t_jurusan where id_jur >1");
while ($data = mysqli_fetch_row($hasil))
{

$kodejur= $data[0];

$jurusan= $data[1];
$quota=$data[4]; 
$kelas=$data[5]; 
$totalkelas+=$kelas; 
$totalquota+=$quota; 

$hasil2 = mysqli_query($db,"SELECT count(*) as jum FROM master WHERE jrsn_pil1 = '$kodejur'");
$data2 = mysqli_fetch_row($hasil2);
$jumlah = $data2[0]; 

$hasillaki = mysqli_query($db,"SELECT count(*) as laki FROM master WHERE s_jk='1' and jrsn_pil1 = '$kodejur'");
$datalaki = mysqli_fetch_row($hasillaki);
$jumlahlaki = $datalaki[0]; 

$hasilP = mysqli_query($db,"SELECT count(*) as P FROM master WHERE s_jk='2' and jrsn_pil1 = '$kodejur'");
$dataP = mysqli_fetch_row($hasilP);
$jumlahP = $dataP[0]; 

$kurang=$jumlah-$quota;
$totalsiswa += $jumlah; 
$totallaki+= $jumlahlaki; 
$totalP+= $jumlahP; 
$totalkurang+=$kurang;


echo "<tr><td>".$no."</td><td>".$jurusan."</td><td>".$kelas."</td><td>".$jumlahlaki."</td><td>".$jumlahP."</td><td>".$jumlah."&nbsp Siswa</td><td>".$quota."&nbsp Siswa</td><td>".$kurang."&nbsp Siswa</td>";


$no++;
}

echo "<tr><td colspan='2'>JUMLAH</td><td>".$totalkelas."</td><td>".$totallaki."</td><td>".$totalP."</td><td>".$totalsiswa."&nbsp Siswa</td><td>".$totalquota."&nbsp Siswa</td><td>".$totalkurang."&nbsp Siswa</td>";



?>
</table> 
</div>	  
	 
</table> 	 
	  
    </div> <!-- /container -->

	<div class="row-fluid">
			<div class="span12">
			  <div class="row-fluid">
				<div class="alert alert-info">
					<a name="contact"></a>
				  <h2>www.andeznet.com</h2>
				  <p class="text-info">Gudang Teknologi & Informasi</p>
				  <p>&copy; <a href="http://andeznet.com">www.andeznet.com</a>&nbsp<?php echo date("Y");?></p>
				</div><!--/span-->
			  </div><!--/row-->
			</div><!--/span-->
	</div><!--/row-->
	
	
    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
	
	<script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/css/easypiechart/jquery.easy-pie-chart.js"></script>
	
	<script>
        $(function() {
            // Easy pie charts
            $('.chart').easyPieChart({animate: 1000});
        });
     </script>

  </body>
</html>
