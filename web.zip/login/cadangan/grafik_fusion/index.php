<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="Grafik Fusion">
    <meta name="author" content="Hakko Bio Richard">
    <link rel="icon" href="../../favicon.ico">

    <title>Menampilkan data di fusion chart dengan PHP, MySQLi dan Bootstrap 3</title>

    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="navbar-fixed-top.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="http://www.hakkoblogs.com">Hakko Blog's</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="http://www.hakkoblogs.com">Tutorial</a></li>
            <li><a href="http://www.hakkoblogs.com">PHP</a></li>
            <li><a href="http://www.hakkoblogs.com">MySQLi</a></li>
            <!-- <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Something else here</a></li>
                <li role="separator" class="divider"></li>
                <li class="dropdown-header">Nav header</li>
                <li><a href="#">Separated link</a></li>
                <li><a href="#">One more separated link</a></li>
              </ul>
            </li> -->
          </ul>
          <!-- <ul class="nav navbar-nav navbar-right">
            <li><a href="../navbar/">Default</a></li>
            <li><a href="../navbar-static-top/">Static top</a></li>
            <li class="active"><a href="./">Fixed top <span class="sr-only">(current)</span></a></li>
          </ul> -->
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container">

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
        <center><h2>Grafik Mahasiswa</h2></center>
        
      </div>
    <?php 
    include "conn.php";
      //$sql = mysqli_query($koneksi, "SELECT t_gr.f_grno, MONTH(t_gr.f_grdate) AS bulan, YEAR(t_gr.f_grdate) AS tahun, SUM(t_gr_detail.f_received_qty) AS total FROM t_gr, t_gr_detail WHERE t_gr.f_grno=t_gr_detail.f_grno AND t_gr_detail.f_partcode='$partcode' AND YEAR(t_gr.f_grdate)='$tahun' AND MONTH(t_gr.f_grdate)='1'");
			$sql = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='1'");
			
            $row = mysqli_fetch_array($sql); 
            
            $sql1 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='2'");
			
            $row1 = mysqli_fetch_array($sql1);
            
            $sql2 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='3'");
			
            $row2 = mysqli_fetch_array($sql2);
            
            $sql3 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='4'");
			
            $row3 = mysqli_fetch_array($sql3);
            
            $sql4 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='5'");
			
            $row4 = mysqli_fetch_array($sql4);
            
            $sql5 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='6'");
			
            $row5 = mysqli_fetch_array($sql5);
            
            $sql6 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='7'");
			
            $row6 = mysqli_fetch_array($sql6);
            
            $sql7 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='8'");
			
            $row7 = mysqli_fetch_array($sql7);
            
            $sql8 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='9'");
			
            $row8 = mysqli_fetch_array($sql8);
            
            $sql9 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='10'");
			
            $row9 = mysqli_fetch_array($sql9);
            
            $sql10 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='11'");
			
            $row10 = mysqli_fetch_array($sql10);
            
            $sql11 = mysqli_query($koneksi, "SELECT COUNT(tanggal_lahir) AS total FROM data WHERE MONTH(tanggal_lahir)='12'");
			
            $row11 = mysqli_fetch_array($sql11);
            
            ?>
<table id="TableSiswa" class="table table-bordered" border="0" align="center" cellpadding="10">
                <tr>
                <th>Bulan</th>
                <th>Jan</th>
                <th>Feb</th>
                <th>Mar</th>
                <th>Apr</th>
                <th>Mei</th>
                <th>Jun</th>
                <th>Jul</th>
                <th>Ags</th>
                <th>Sep</th>
                <th>Okt</th>
                <th>Nov</th>
                <th>Des</th>
                </tr>
            
                <tr>
                <td>Mahasiswa</td>
                <td><?php echo $row['total'];?></td>
                <td><?php echo $row1['total'];?></td>
                <td><?php echo $row2['total'];?></td>
                <td><?php echo $row3['total'];?></td>
                <td><?php echo $row3['total'];?></td>
                <td><?php echo $row3['total'];?></td>
                <td><?php echo $row3['total'];?></td>
                <td><?php echo $row3['total'];?></td>
                <td><?php echo $row3['total'];?></td>
                <td><?php echo $row3['total'];?></td>
                <td><?php echo $row3['total'];?></td>
                <td><?php echo $row3['total'];?></td>
                </tr> 
                <?php
                $sqlku = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='1'");
			
                $rowku = mysqli_fetch_array($sqlku); 
                
                $sqlku1 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='2'");
			
                $rowku1 = mysqli_fetch_array($sqlku1); 
                
                $sqlku2 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='3'");
			
                $rowku2 = mysqli_fetch_array($sqlku2); 
                
                $sqlku3 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='4'");
			
                $rowku3 = mysqli_fetch_array($sqlku3); 
                
                $sqlku4 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='5'");
			
                $rowku4 = mysqli_fetch_array($sqlku4); 
                
                $sqlku5 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='6'");
			
                $rowku5 = mysqli_fetch_array($sqlku5); 
                
                $sqlku6 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='7'");
			
                $rowku6 = mysqli_fetch_array($sqlku6); 
                
                $sqlku7 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='8'");
			
                $rowku7 = mysqli_fetch_array($sqlku7); 
                
                $sqlku8 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='9'");
			
                $rowku8 = mysqli_fetch_array($sqlku8); 
                
                $sqlku9 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='10'");
			
                $rowku9 = mysqli_fetch_array($sqlku9); 
                
                $sqlku10 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='11'");
			
                $rowku10 = mysqli_fetch_array($sqlku10); 
                
                $sqlku11 = mysqli_query($koneksi, "SELECT SUM(sks) AS total1 FROM data WHERE MONTH(tanggal_lahir)='12'");
			
                $rowku11 = mysqli_fetch_array($sqlku11); 
                ?>
                
                <tr>
                <td>Out</td>
                <td><?php echo $rowku['total1'];?></td>
                <td><?php echo $rowku1['total1'];?></td>
                <td><?php echo $rowku2['total1'];?></td>
                <td><?php echo $rowku3['total1'];?></td>
                <td><?php echo $rowku4['total1'];?></td>
                <td><?php echo $rowku5['total1'];?></td>
                <td><?php echo $rowku6['total1'];?></td>
                <td><?php echo $rowku7['total1'];?></td>
                <td><?php echo $rowku8['total1'];?></td>
                <td><?php echo $rowku9['total1'];?></td>
                <td><?php echo $rowku10['total1'];?></td>
                <td><?php echo $rowku11['total1'];?></td>
                </tr>
        </table>
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="dist/js/jquery-1.4.js"></script>
    <!-- <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>-->
    <script type="text/javascript" src="dist/js/bootstrap.min.js"></script>
    
    <script type="text/javascript" src="dist/js/jquery.fusioncharts.js"></script>
    
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script type="text/javascript" src="assets/js/ie10-viewport-bug-workaround.js"></script>
    
    <!--LOAD HTML KE JQUERY FUSION CHART BERDASARKAN ID TABLE-->
<script>
    $('#TableSiswa').convertToFusionCharts({
        swfPath: "Charts/",
        type: "MSColumn3D",
        data: "#TableSiswa",
        width: "1050",
        height: "350",
        dataFormat: "HTMLTable",
        renderAt: "chart-container",
        dataOption:{
            chartAttributes:{
                caption: "Annual Stock Graph",
                xAxisName: "Month",
                yAxisName: "Qty Stock",
                decimalPrecision: "0"
            }
        }
    });

        </script>
  </body>
</html>
