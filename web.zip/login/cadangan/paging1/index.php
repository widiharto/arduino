<!DOCTYPE HTML>
<html>
<head>
	<title>Ajax Pagination - Dewa Coding 21</title>
	
	<link rel='stylesheet' type='text/css' href='style.css' />
	
	<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function() {
		$("#results" ).load( "fetch_pages.php");
		
		$("#results").on( "click", ".pagination a", function (e){
			e.preventDefault();
			var page = $(this).attr("data-page");
			$("#results").load("fetch_pages.php",{"page":page}, function(){});
		});
	});
	</script>
</head>
<body>
	<div id="results"><!-- content akan tampil disini --></div>
</body>
</html>
