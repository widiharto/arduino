<?php
if(isset($_POST) && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
	
	include("config.inc.php"); 
	if(isset($_POST["page"])){
		$page_number = filter_var($_POST["page"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH);
		if(!is_numeric($page_number)){die('Invalid page number!');}
	}else{
		$page_number = 1;
	}
	
	$results = $mysqli->query("SELECT COUNT(*) FROM data1");
	$get_total_rows = $results->fetch_row();
	$total_pages = ceil($get_total_rows[0]/$item_per_page);
	
	$page_position = (($page_number-1) * $item_per_page);
	

	$results = $mysqli->prepare("SELECT * FROM data1 ORDER BY no DESC LIMIT $page_position, $item_per_page");
	$results->execute();
	$results->bind_result($no, $hari, $tanggal, $suhu, $durasisemprot, $durasilampu, $durasinormal);
	
?>
	<div class='table'>
		<h2 align='center'>Tabel Penyiraman</h2>
		<table border='1px'>
			<tr>
				<td><b>No</b></td>
				<td><b>Hari</b></td>
				<td><b>Tanggal / Waktu</b></td>
				<td><b>Suhu (°C)</b></td>
				<td><b>Durasi Pompa (s)</b></td>
				<td><b>Durasi Lampu (s)</b></td>
				<td><b>Durasi Normal (s)</b></td>
			</tr>
			<?php
			$num = 0 ;
			while($i = $results->fetch()) :
				$num = $num + 1;
			 ?>
			<tr>
				<td><?php echo $num; ?></td>
				<td><?php echo $hari; ?></td>
				<td><?php echo $tanggal; ?></td>
				<td><?php echo $suhu; ?></td>
				<td><?php echo $durasisemprot; ?></td>
				<td><?php echo $durasilampu; ?></td>
				<td><?php echo $durasinormal; ?></td>
			</tr>
			<?php endwhile; ?>
		</table>
		<?php echo paginate_function($item_per_page, $page_number, $get_total_rows[0], $total_pages); ?></td>
	</div>
<?php	
	exit;
}
function paginate_function($item_per_page, $current_page, $total_records, $total_pages)
{
    $pagination = '';
    if($total_pages > 0 && $total_pages != 1 && $current_page <= $total_pages){
        $pagination .= '<ul class="pagination">';
        
        $right_links    = $current_page + 3; 
        $previous       = $current_page - 3;
        $next           = $current_page + 1;
        $first_link     = true;
        
        if($current_page > 1){
			$previous_link = ($previous==0)? 1: $previous;
            $pagination .= '<li class="first"><a href="#" data-page="1" title="First">First</a></li>';
            $pagination .= '<li><a href="#" data-page="'.$previous_link.'" title="Previous">Previous</a></li>';
                for($i = ($current_page-2); $i < $current_page; $i++){
                    if($i > 0){
                        $pagination .= '<li><a href="#" data-page="'.$i.'" title="Page'.$i.'">'.$i.'</a></li>';
                    }
                }   
            $first_link = false;
        }
        
        if($first_link){
            $pagination .= '<li class="first active">'.$current_page.'</li>';
        }elseif($current_page == $total_pages){
            $pagination .= '<li class="last active">'.$current_page.'</li>';
        }else{
            $pagination .= '<li class="active">'.$current_page.'</li>';
        }
                
        for($i = $current_page+1; $i < $right_links ; $i++){
            if($i<=$total_pages){
                $pagination .= '<li><a href="#" data-page="'.$i.'" title="Page '.$i.'">'.$i.'</a></li>';
            }
        }
        if($current_page < $total_pages){ 
				$next_link = ($i > $total_pages) ? $total_pages : $i;
                $pagination .= '<li><a href="#" data-page="'.$next_link.'" title="Next">Next</a></li>';
                $pagination .= '<li class="last"><a href="#" data-page="'.$total_pages.'" title="Last">Last</a></li>';
        }
        
        $pagination .= '</ul>'; 
    }
    return $pagination;
}
?>

