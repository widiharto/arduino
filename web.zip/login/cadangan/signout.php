<?php
include "../koneksi.php";
// include "../ethernet.php";

//$masuk= "INSERT INTO data1 (no,hari,tanggal,suhu,durasisemprot,durasilampu,durasinormal) VALUES (NULL,'$hari','$datetime',$suhu,10,0,0)";
//@mysqli_query($conn, $masuk);  // untuk input data ke databse

@$input="INSERT INTO `user` (`username`, `password`, `nama`, `status`) VALUES ('$username', '$password', '$nama', '$status')";
@$username = $_POST['username'];
@$password = $_POST['password'];
@$nama = $_POST['nama'];
@$status = $_POST['status'];
@$submit = 

mysqli_query($conn, $input);

?>

<html>
<head>
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
    <link href="../css/bootstrap.css" rel="stylesheet" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
        <title>AUTOMATIC SPRINKLERS</title>
<style>
.navbar-inverse {
    border-radius: 0;
}
</style>
</head>
<body>

<nav class="navbar navbar-inverse">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/login" title="AUTOMATIC SPRINKLERS"><img src="mn.png" width="25" height="25">AUTOMATIC SPRINKLERS</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
              <?php
                session_start();
                error_reporting(E_ALL^E_NOTICE);
                $halaman = $_GET['halaman'];

                if($_SESSION['status']=="admin"){
                  echo "
                      <li><a href='index.php' title='Home'><span class='glyphicon glyphicon-home'></span> Home</a></li>
                      <li><a href='?halaman=view' title='View Table'><span class='glyphicon glyphicon-eye-open'></span> View Table</a></li>
                      <li><a href='?halaman=manual' title='Manual Control'><span class='glyphicon glyphicon-hand-up'></span> Manual Control</a></li>
                      <li><a href='?halaman=stop' title='Emergency STOP'><span class='glyphicon glyphicon-off'></span> Emergency STOP</a></li>
                      <li><a href='logout.php' title='Logout'><span class='glyphicon glyphicon-log-out'></span> Logout</a></li>
                  ";
                  
                }else{
                  echo "
                      <li><a href='login.php' title='Login Here !'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>
                  ";
                }
                ?>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

<!-- <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Projects</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav> -->





<!-- <nav class="navbar navbar-inverse">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/login" title="AUTOMATIC SPRINKLERS">AUTOMATIC SPRINKLERS</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
                <li><a href='?halaman=stop' title='Emergency STOP'>Emergency STOP</a></li>
                <li><a href='logout.php' title='Logout'>Logout</a></li>
          </ul>
        </div>
      </div>
    </nav> -->
<div class="container">
<?php
// echo "Suhu saat ini ".$suhu."°C";
?>
</div>
<div class="container">
<hr/>
</div>
    <div class="container" style="max-width: 280px;">
        <div class="row" align="center">
            <h2>Sign Out</h2>
            <div class="login">
                <form role="form" action="signout.php" method="post">
                    <div class="form-group">
                        <input type="text" name="nama" class="form-control" placeholder="Name" title="Name" required autofocus />
                    </div>
                    <div class="form-group">
                        <label for="focusedInput" class="col-sm-2 control-label"></label>
                            <div>
                                <select id="focusedInput" class="form-control">
                                    <option>Admin</option>
                                    <option>User</option>
                                </select>
                            </div>

<!--                         <input type="text" name="status" class="form-control" placeholder="Employe" title="Employe" required autofocus /> -->
                    </div>
                    <div class="form-group">
                        <input type="text" name="username" class="form-control" value="Username" title="Username" required autofocus />
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="Password" title="Password" required autofocus />
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" class="btn btn-primary btn-block" value="Sign Out" title="Sign Out" />
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="container">
    <hr/>
        <p>&copy; 2016 <a href="/login" title="AUTOMATIC SPRINKLERS">AUTOMATIC SPRINKLERS</a></p>
    </div>
</body>
</html>