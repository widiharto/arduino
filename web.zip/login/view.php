<?php
include('koneksi.php');
include "hari.php";
include "durasi.php";
include "pagination.php";

if (isset($_GET['awal']) AND isset($_GET['akhir'])) {
	$awal = $_GET['awal'];
	$akhir = $_GET['akhir'];
	$hasil = $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' ORDER BY no DESC");
	$rows = $hasil->num_rows;
	$pager = new Pagination("/login/index.php?halaman=view&awal={$awal}&akhir={$akhir}", $rows);
	$pager = $pager->get();
	$hasil = $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' ORDER BY no DESC LIMIT {$pager['perpage']} OFFSET {$pager['offset']}");
}
else {
	$hasil = $conn->query("SELECT * FROM data2 ORDER BY no DESC");
	$rows = $hasil->num_rows;
	$pager = new Pagination("/login/index.php?halaman=view", $rows);
	$pager = $pager->get();
	$hasil = $conn->query("SELECT * FROM data2 ORDER BY no DESC LIMIT {$pager['perpage']} OFFSET {$pager['offset']}");
}

//Nyeluk data di  mana durasi semprot = 10 detik
// $hasil = $conn->query("SELECT * FROM data1 WHERE durasisemprot =10");
//Nyeluk data di  mana waktu 1 jam terakir
?>


<h2 align="center">TABEL PENYIRAMAN</h2>
<center>
Hari
<?php
echo $hari;
?>,
<?php
echo $tanggal;
?>
<div align="center">
<?php
echo "Pukul : ";
echo $waktu;
?>
<br />
<!-- refresh page 5 menit input data hari tanggal waktu -->
</div>
<br><br>
<!-- /////////////// -->

<form method="get" align="left">
<input type="hidden" name="halaman" value="view" />
<div class="col-md-6">
	<div class='col-md-2' style="padding-top: 6px;font-weight: bold;">
		Mulai
	</div>
    <div class='col-md-3'>
        <div class="form-group">
            <div class='input-group date'>
                <input type='text' name="awal" class="form-date form-control" style="border-radius: 5px;" required />
            </div>
        </div>
    </div>
    <div class='col-md-2' style="padding-top: 6px;font-weight: bold;">
    sampai
    </div>
    <div class='col-md-3'>
        <div class="form-group">
            <div class='input-group date'>
                <input type='text' name="akhir" class="form-date form-control" style="border-radius: 5px;" required />
            </div>
        </div>
    </div>
    <div class='col-md-2'>
		<button class="btn btn-info">Filter</button>
	</div>
</div>
</form>
<script type="text/javascript">
    $(function () {
        $(".form-date").datetimepicker({
	        format: "yyyy-mm-dd",
	        weekStart: 1,
	        todayBtn:  1,
			autoclose: 1,
			todayHighlight: 1,
			startView: 2,
			minView: 2,
			forceParse: 0,
	    });
    });
</script>
<!-- //////////////// -->
<br>
<table <?php if (  isset($_GET['print'])) : ?> width="100%" border="1px solid" <?php endif; ?> class="table table-striped table-responsive">

<tr align="center" >
<td ><b>No</b></td>
<td ><b>Hari</b></td>
<td ><b>Tanggal / Waktu</b></td>
<td ><b>Suhu (°C)</b></td>
<td ><b>Kelembaban (%)</b></td>
<td ><b>Periode Refresh Data Pompa (s)</b></td>
<td ><b>Periode Refresh Data Lampu (s)</b></td>
<td ><b>Periode Refresh Data Pompa & Lampu (s)</b></td>
<td ><b>Periode Refresh Data Normal (s)</b></td>
</tr>
<?php 
//$no = 0 ;
$no = $pager['offset'] ;

while($i = $hasil->fetch_assoc()) :
	$no = $no + 1;
 ?>

	<tr align="center">
	<td><?php echo $no ?></td>
	<td><?php echo $i['hari']; ?></td>
	<td><?php echo $i['tanggal']; ?></td>
	<td><?php echo $i['suhu']; ?></td>
	<td><?php echo $i['kelembaban']; ?></td>
	<td><?php echo $i['durasisemprot']; ?></td>
	<td><?php echo $i['durasilampu']; ?></td>
	<td><?php echo $i['durasisemprotlampu']; ?></td>
	<td><?php echo $i['durasinormal']; ?></td>
	</tr>
	
<?php endwhile; ?>
</table>
<p align="left">* Data di perbaruhi setiap 10 detik</p>
	<?php if ($pager['is_needed']) : ?>
	<ul class="pagination">
	<?php if ($pager['link']['firstpage']) : ?><li><a href="<?php echo $pager['link']['firstpage']?>"><?php echo $pager['number']['firstpage']?></a></li><?php endif; ?>
	<?php if ($pager['link']['firstbutton']) : ?><li><a href="<?php echo $pager['link']['firstbutton']?>"><?php echo $pager['number']['firstbutton']?></a></li><?php endif; ?>
	<?php if ($pager['link']['secondbutton']) : ?><li><a href="<?php echo $pager['link']['secondbutton']?>"><?php echo $pager['number']['secondbutton']?></a></li><?php endif; ?>
	<?php if ($pager['link']['lastpage']) : ?><li><a href="<?php echo $pager['link']['lastpage']?>"><?php echo $pager['number']['lastpage']?></a></li><?php endif; ?>
	</ul>
	<?php endif;?>
</center>
<b>
<?php
 echo 'Durasi pompa adalah '.($durpom*10).' detik'.'</br>';
 echo 'Durasi lampu adalah '.($durlam*10).' detik'.'</br>';
 echo 'Durasi pompa & lampu adalah '.($durpomlam*10).' detik'.'</br>';
 echo 'Durasi normal adalah '.($durnor*10).' detik'.'</br>';
?>
</b>
<body>
<center></br>
	<?php if (isset($_GET['awal']) AND isset($_GET['akhir'])) : ?>
		<a href="cetak.php?awal=<?=$_GET['awal']?>&akhir=<?=$_GET['akhir']?>" class="btn btn-success btn-lg" title="Simpan ke PDF"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Simpan ke PDF</a><br><br>
	<?php else : ?>
		<a href="cetak.php" class="btn btn-success btn-lg" title="Simpan ke PDF"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Simpan ke PDF</a><br><br>
	<?php endif;?>
	<a href="c.php" class="btn btn-lg btn-danger" title="Berhenti Darurat"><span class="glyphicon glyphicon-off"></span> Berhenti Darurat</a>
</center>