<?php
session_start();
session_destroy();
?>

<script language script="JavaScript">
alert('Anda Keluar');
document.location='index.php';
</script>