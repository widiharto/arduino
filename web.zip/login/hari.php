<?php
switch (date("N")) {
  case 1:
    $hari = "Senin";# code...
    break;
  
  case 2:
    $hari = "Selasa";# code...
    break;
  
  case 3:
    $hari = "Rabu";# code...
    break;
  
  case 4:
    $hari = "Kamis";# code...
    break;

  case 5:
    $hari = "Jumat";# code...
    break;
  
  case 6:
    $hari = "Sabtu";# code...
    break;
  
  case 7:
    $hari = "Minggu";# code...
    break;
  
  default:
    $hari = "";
    break;
}
?>
<?php
$waktu=date("H:i:s");
$tanggal=date("d/m/y");
$datetime=date("Y-m-d H:i:s")
?>