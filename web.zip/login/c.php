<?php
$fp =fopen("COM3","w");
?>
<script language script="JavaScript">
	alert('SYSTEM OFF');
	document.location='index.php';
</script>
<meta http-equiv="refresh" content="0;URL='index.php'" />   
<html>
<head>
	<title></title>
</head>
<body>
<a href="index.php">KEMBALI</a>
</body>
</html>
<?php
fwrite($fp, "C");
fclose($fp);
?>
 