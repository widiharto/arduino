<?php
$url = "http://192.168.1.177/";
$data =file_get_contents($url);
$suhu = $data;

$suhuku =substr($suhu, 0, 5);
$kelembaban =substr($suhu, 6);
?>