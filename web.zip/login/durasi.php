<?php
if (isset($_GET['awal']) AND isset($_GET['akhir'])) {
	$awal = $_GET['awal'];
	$akhir = $_GET['akhir'];
	$Normal =  $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' AND durasinormal =10");
	$Pompa =  $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' AND durasisemprot =10");
	$PompaLampu =  $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' AND durasisemprotlampu =10");
	$Lampu =  $conn->query("SELECT * FROM data2 WHERE tanggal BETWEEN '$awal' AND '$akhir' AND durasilampu =10");
}
else{
	$Normal =  $conn->query("SELECT * FROM data2 WHERE durasinormal =10");
	$Pompa =  $conn->query("SELECT * FROM data2 WHERE durasisemprot =10");
	$PompaLampu =  $conn->query("SELECT * FROM data2 WHERE durasisemprotlampu =10");
	$Lampu =  $conn->query("SELECT * FROM data2 WHERE durasilampu =10");
}

$durnor = 0 ;
$durpom = 0 ;
$durlam = 0 ;
$durpomlam = 0 ;

while($a = $Normal->fetch_assoc()) :
	$durnor = $durnor + 1;
 endwhile;
while($a = $Pompa->fetch_assoc()) :
	$durpom = $durpom + 1;
 endwhile;
while($a = $PompaLampu->fetch_assoc()) :
	$durpomlam = $durpomlam + 1;
 endwhile;
while($a = $Lampu->fetch_assoc()) :
	$durlam = $durlam + 1;
 endwhile;

 $durjum = $durnor+$durpom+$durlam+$durpomlam;

$wdurnor = 'width:'.$durnor/$durjum*100;
$wdurpom = 'width:'.$durpom/$durjum*100;
$wdurpomlam = 'width:'.$durpomlam/$durjum*100;
$wdurlam = 'width:'.$durlam/$durjum*100;
?>