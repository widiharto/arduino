<?php
include "koneksi.php";
$hasil = $conn->query("SELECT * FROM about");
?>
<html>
<head>
	<title>AUTOMATIC SPRINKLERS</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>	
</head>
<body>

   <div class="container">		
	<center><h1>Hardware</h1></center>
	<br/>
	<div class="col-md-8 col-md-offset-2">
		<div id="myCarousel" class="carousel slide" data-ride="carousel">
			<!-- Indicators -->
			<ol class="carousel-indicators">
				<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				<li data-target="#myCarousel" data-slide-to="1"></li>
				<li data-target="#myCarousel" data-slide-to="2"></li>		
			</ol>

			<!-- deklarasi carousel -->
			<div class="carousel-inner" align="center" role="listbox">
				<div class="item active">
					<img src="img/arduino_uno.png">
					<div class="carousel-caption">
						<h3></h3>
						<p></p>
					</div>
				</div>
				<div class="item">
					<img src="img/ethernet_shield.png">
					<div class="carousel-caption">
						<h3></h3>
						<p></p>
					</div>
				</div>
			</div>

			<!-- membuat panah next dan previous -->
			<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
	</div>
   </div></br>
<hr><br>

<center>
<table width="100%" border="0px solid" class="table table-striped table-responsive">
<tr align="center" >
	<td width="50%"><b>Petunjuk Aplikasi</b></td>
	<td width="50%"><b>Tentang Aplikasi</b></td>
</tr>
<tr align="justify">
	<td>
		<b>></b> Klik login dibagian pojok kanan atas unutk masuk ke sistem<br>
		<b>></b> Isikan username dan password lalu tekan Log In<br>
		<b>></b> Menu Table adalah menu tabel monitoring penyiraman otomatis<br>
		<b>></b> Pada menu Table, tabel penyiraman juga bisa di cetak dalam PDF<br>
		<b>></b> Menu Manual Control adalah kontrol manual untuk penyiraman<br>
		<b>></b> Menu Emergency Stop adalah menghentikan sistem otomatisasi arduino<br>
		<b>></b> Untuk keluar dari sistem klik logout
	</td>
	<td>
		<b>></b> Aplikasi sistem monitoring penyiram tanaman otomatis ini dinamakan Automatic Sprinklers<br>
		<b>></b> Automatic Sprinklers merupakan pemantau penyiraman jarak jauh berbasis website<br>
		<b>></b> Melalui website ini kita dapat memantau durasi penyiraman dan suhu tanah<br>
		<b>></b> Jadi kita dapat memantau penyiraman lebih praktis
	</td>
</tr>
</table>
</center>
</body>
</html>